jQuery(document).ready(function ($) {
    $('body').on('click', '.jkhgfdfgh', function (e) {
        e.preventDefault();
        var bu = jQuery(this);
        bu.attr('aria-disabled', true);
        let uil = $('#sadafio_token_url').val();
        // var ppp = jQuery('#sadafio_phonenumber_url').val();
        // if (!ppp) {
        //     ppp = idehweb_sadafio.phonenumber;
        // }

        // var mmm = jQuery('#sadafio_melicode_url').val();
        // if (!mmm) {
        //     mmm = idehweb_sadafio.melicode;
        // }
        if (!uil) {
            alert('enter url!');
            return;
        }
        jQuery('.sdfghghfdercfr').html('sending request... wait please...');

        var myHeaders = new Headers();
        myHeaders.append("ApiKey", idehweb_sadafio.header_api);
        myHeaders.append("Content-Type", "application/json");

        var raw = JSON.stringify({
            "url": uil,
            "phoneNumber": "",
            "meliCode": "",
            "CompanyMeliCode": ""
        });

        var requestOptions = {
            method: 'POST',
            headers: myHeaders,
            body: raw,
            redirect: 'follow'
        };
        bu.after('<div class="siloader"></div>');
        fetch("https://api1ir.sadaf.io/api/v1/Recognition/RecognizeFromUrl", requestOptions)
            .then(response => response.text())
            .then(result => {
                bu.attr('aria-disabled', false);

                result = JSON.parse(result);
                console.log(result);

                jQuery('.siloader').remove();
                jQuery('.sdfghghfdercfr').empty();
                // if (result.message)
                jQuery('.sdfghghfdercfr').html(result.message);
                // if (result.Message)
                //     jQuery('.sdfghghfdercfr').html(result.Message);

                if (result.isSuccess == true && result.httpStatusCode == 200) {
                    // var radio = jQuery('input[name="choose_type_url"]:checked').val();
                    // console.log('radio', radio, uil);
                    // if (radio == 128 || radio == 320) {
                    //     jQuery('div[data-name="music' + radio + '"] input').val(uil);
                    // } else {
                    //     jQuery('div[data-name="video' + radio + '"] input').val(uil);

                    // }
                } else {
                    jQuery('.sdfghghfdercfr').html(result.message);

                }
            })
            .catch(error => {
                console.log('error', error);
                bu.attr('aria-disabled', false);
                jQuery('.siloader').remove();

            });

    });
    $('body').on('click', '.kjhg.v1', function (e) {
        e.preventDefault();
        $('.kjhgfrdfghuj1').removeClass('none');
        $('.kjhgfrdfghuj2').addClass('none');
    });
    $('body').on('click', '.kjhg.v2', function (e) {
        e.preventDefault();

        $('.kjhgfrdfghuj2').removeClass('none');
        $('.kjhgfrdfghuj1').addClass('none');
    });
});

var openFile = function (event) {
    var formData = new FormData();

    event.preventDefault();
    var bu = jQuery('.kiuygfdgh button');

    var file = jQuery('#sadafio_token').prop('files')[0];
    if (!file) {
        return;
    }
    bu.after('<div class="siloader"></div>');

    jQuery('.sdfghghfdercfr').html('Generating files... wait please...');
    var bu = jQuery(this);
    bu.attr('aria-disabled', true);


    console.log('file;', file);

    function blobToFile(theBlob, fileName) {

        return new File([theBlob], fileName, {lastModified: new Date().getTime(), type: "video/mp4"})
    }

    function downloadBlob(blob, basename) {

        console.log('downloadBlob', blob);
        basename = basename || "output";

        let url = URL.createObjectURL(blob);
        // console.log('url', url);

        let a = document.createElement("a");
        document.body.appendChild(a);
        a.style.display = "none";
        a.href = url;
        a.download = `${basename}.${blob.type.split("/")[1]}`;
        let thef = blobToFile(blob, a.download);
        console.log('file', thef);

        formData.append("files", thef);
        console.log('FormData', formData);

        // a.click();
        URL.revokeObjectURL(url);
        document.body.removeChild(a);
    }

    // download memfs data
    function downloadData(data, basename) {
        downloadBlob(
            new Blob([data], {
                type: "audio/mp4",
            }),
            basename
        );
    }

    // upload generated file
    function uploadData(data, basename) {
        // basename = basename || "output";
        new Blob([data], {
            type: "audio/mp4",
        })
        // formData.append("files",c);
        // console.log('ff fomrData',formData);
        // reset of the upload
    }

    // initializations
    const init = async () => {
        const path = "../wp-content/plugins/sadaf-io/scripts/ffmpeg-worker.js";
        console.log("init ", path);
        let worker = new Worker(path);
        let dateStart;

        dateStart = new Date();
        console.log("started at", dateStart);

        // split video into 10 minutes audio files
        let metadata = await analyze(file);
        let fd = file.type.split('/');
        console.info("metadata:", metadata);
        // const sliceLength = 10 * 60; //seconds
        console.log('metadata.video.length', fd[0]);
        let sliceLength;
        let totalSlices;
        if (fd[0] == 'video') {
            // sliceLength = parseInt(idehweb_sadafio.duration_of_every_slice); //seconds
            // totalSlices = parseInt(idehweb_sadafio.count_of_slices);
            sliceLength = parseInt(5); //seconds
            totalSlices = parseInt(5);
        } else {
            // sliceLength = parseInt(idehweb_sadafio.duration_of_every_slice_fau); //seconds
            // totalSlices = parseInt(idehweb_sadafio.count_of_slices_fau);
            sliceLength = parseInt(5); //seconds
            totalSlices = parseInt(2);
        }
        console.log('sliceLength', sliceLength);
        console.log('totalSlices', totalSlices);
        let slicedData = [];

        for (let i = 0; i < totalSlices; i++) {
            let start = i * sliceLength;
            let startFormatted2 = (metadata.duration / totalSlices) * i;
            // console.log('metadata.duration: ',metadata.duration,' / ','totalSlices: ',totalSlices,' = ',startFormatted2);
            let startFormatted = new Date(startFormatted2 * 1000).toISOString().substr(11, 8);
            // let sum=(parseInt(start) + parseInt(sliceLength))
            // console.log('start ',start,' sliceLength ', sliceLength,' = ',sum, metadata.duration);

            let length = start + sliceLength > metadata.duration ? null : sliceLength;
            console.log('start trimming from ', startFormatted, ' to ', length);
            var data = await convertVideo(file, i, startFormatted, length);
            slicedData.push(data.data.MEMFS[0]);

            // you could download each part separately
            downloadData(data.data.MEMFS[0].data, `output_${String(i).padStart(2, '0')}`);
        }

        // check if video length is less than 10 minutes and does it need splitting into 10 mins?
        let finalData;
        if (slicedData.length > 1) {
            // concat separate audio files into a single file
            let concatData = await concat(slicedData);
            finalData = concatData.data.MEMFS[0].data;
        } else {
            // no need to concat, video length is less than 10 minutes
            finalData = slicedData[0].data;
        }

        // downloadData(finalData);
        // OR:
        // uploadData(finalData);

        var diffDate = new Date().getTime() - dateStart.getTime();
        console.log(`finished convertion in ${diffDate / 1000} seconds`);

        const blobFile = new Blob([finalData], {
            type: "audio/mp4",
        });
        // console.log('blobFile', blobFile);
        // console.log('formData', formData);
        // var ppp = document.getElementById('sadafio_phonenumber').value;

        // if (!ppp) {
        //     ppp = idehweb_sadafio.phonenumber;
        // }

        // var mmm = document.getElementById('sadafio_melicode').value;
        // if (!mmm) {
        //     mmm = idehweb_sadafio.melicode;
        // }
        // var mmmc = document.getElementById('sadafio_company_melicode').value;
        // if (!mmmc) {
        //     mmmc = idehweb_sadafio.companymelicode;
        // }
        formData.append('PhoneNumber', "");
        formData.append('MeliCode', "");
        formData.append('CompanyMeliCode', "");
        if (metadata.duration && parseInt(metadata.duration))
            formData.append('Duration', parseInt(metadata.duration));

        jQuery('.sdfghghfdercfr').html('Sending request...');

        var myHeaders = new Headers();
        myHeaders.append("ApiKey", idehweb_sadafio.header_api);
        fetch('https://api1ir.sadaf.io/api/v1/Recognition/RecognizeCropped', {
            method: 'POST',
            body: formData,
            headers: myHeaders,
            redirect: 'follow'
        }).then(r => r.json().then(data => {
            var tr = {status: r.status, body: data};
            console.log(tr);
            bu.attr('aria-disabled', false);
            jQuery('.siloader').remove();
            jQuery('.sdfghghfdercfr').empty();
            // if (r.status == 404) {

            formData.forEach(function (val, key, fD) {
                // here you can add filtering conditions
                formData.delete(key)
            });
            // }
            // if (tr.body.message)
            jQuery('.sdfghghfdercfr').html(tr.body.message);
            // if (tr.body.Message)
            //     jQuery('.sdfghghfdercfr').html(tr.body.Message);

        }))
            .catch(error => {
                jQuery('.siloader').remove();
                jQuery('.sdfghghfdercfr').empty();
                // if (tr.body.message)
                jQuery('.sdfghghfdercfr').html(tr.body.message);
                // if (tr.body.Message)

                formData.forEach(function (val, key, fD) {
                    // here you can add filtering conditions
                    formData.delete(key)
                });
                //     jQuery('.sdfghghfdercfr').html(tr.body.Message);
                console.log('error', error);
                bu.attr('aria-disabled', false);

            });

        return blobFile;


        function convertVideo(source, i, start, length) {
            console.log("converting", source, i, start, length);
            worker?.terminate();
            worker = new Worker(path);

            function cleanup() {
                delete worker.onmessage;
                delete worker.onerror;
                worker.terminate();
            }

            return new Promise((resolve, reject) => {
                let args = ["-ss", start];

                if (length !== null) {
                    args.push("-t");
                    args.push(`${length}`);
                }
                console.log(args);

                worker.postMessage({
                    type: "run",
                    arguments: args.concat([
                        "-i",
                        `/data/${source.name}`,
                        "-vn",
                        "-acodec",
                        "copy",
                        "-preset",
                        "ultrafast",
                        `output_${i}.mp4`,
                    ]),
                    mounts: [
                        {
                            type: "WORKERFS",
                            opts: {
                                files: [source],
                            },
                            mountpoint: "/data",
                        },
                    ],
                });

                worker.onmessage = (e) => {
                    const msg = e.data || {};
                    // console.log(msg)

                    switch (msg.type) {
                        case "error":
                            cleanup();
                            reject(new Error(msg.data));
                            break;

                        case "stdout":
                            break;

                        case "stderr":
                            console.log(msg.data);
                            break;

                        case "done":
                            cleanup();
                            var diffDate = new Date().getTime() - dateStart.getTime();
                            console.log(
                                `finished file of "${i}" in ${diffDate / 1000} seconds`
                            );
                            resolve(e.data);
                            break;

                        default:
                            break;
                    }
                };
                worker.onerror = (e) => {
                    cleanup();
                    reject(e);
                };
            });
        }

        // concat audio files
        function concat(fileList) {
            worker?.terminate();
            worker = new Worker(path);

            function cleanup() {
                delete worker.onmessage;
                delete worker.onerror;
                worker.terminate();
            }

            return new Promise((resolve, reject) => {
                let concatText = "";
                fileList.forEach((element) => {
                    concatText += `file ${element.name}\n`;
                });

                var uint8array = new TextEncoder().encode(concatText);
                fileList.push({name: "concatText.txt", data: uint8array});
                console.log("concat fileList", concatText);

                worker.postMessage({
                    type: "run",
                    arguments: [
                        "-f",
                        "concat",
                        "-safe",
                        "0",
                        "-i",
                        "concatText.txt",
                        "-c",
                        "copy",
                        "output_final.mp4",
                    ],
                    MEMFS: fileList,
                });

                worker.onmessage = (e) => {
                    const msg = e.data || {};
                    switch (msg.type) {
                        case "error":
                            cleanup();
                            reject(new Error(msg.data));
                            break;

                        case "stdout":
                            break;

                        case "stderr":
                            console.log(msg.data);
                            break;

                        case "done":
                            cleanup();
                            resolve(e.data);
                            break;

                        default:
                            break;
                    }
                };
                worker.onerror = (e) => {
                    cleanup();
                    reject(e);
                };
            });
        }

        // extract video metadata
        function analyze(source) {
            function cleanup() {
                delete worker.onmessage;
                delete worker.onerror;
                worker.terminate();
            }

            return new Promise((resolve, reject) => {
                let stderr = [];
                worker.postMessage({
                    type: "run",
                    arguments: ["-i", `/data/${source.name}`],
                    mounts: [
                        {
                            type: "WORKERFS",
                            opts: {
                                files: [source],
                            },
                            mountpoint: "/data",
                        },
                    ],
                });

                worker.onmessage = (e) => {
                    const msg = e.data || {};
                    switch (msg.type) {
                        case "error":
                            cleanup();
                            reject(new Error(msg.data));
                            break;

                        case "stdout":
                            break;

                        case "stderr":
                            stderr.push(msg.data);
                            break;

                        case "done":
                            cleanup();
                            try {
                                const info = parse(stderr);
                                resolve(info);
                            } catch (err) {
                                console.error(err);
                                reject(err);
                            }
                            break;

                        default:
                            break;
                    }
                };
                worker.onerror = (e) => {
                    cleanup();
                    reject(e);
                };
            });
        }

        // parse time helper
        function parseTime(time) {
            if (Number.isFinite(time)) return time;
            // [hh]:[mm]:[ss[.xxx]]
            const m = time.match(/^(?:(\d+):)?(?:(\d+)+:)?(\d+(?:\.\d+)?)$/);
            assert(m, "Invalid time");
            const [hours, minutes, seconds] = m.slice(1);
            let duration = Number(seconds);
            if (hours) {
                if (minutes) {
                    // 1:2:3 -> [1, 2, 3]
                    duration += Number(minutes) * 60;
                    duration += Number(hours) * 3600;
                } else {
                    // 1:2 -> [1, undefined, 2]
                    duration += Number(hours) * 60;
                }
            }
            console.info("duration", duration);
            return duration;
        }

        function assert(condition, message) {
            if (!condition) {
                bu.attr('aria-disabled', false);
                jQuery('.siloader').remove();

                throw new Error(message || "Assertion failed");
            }
        }

        function has(obj, prop) {
            return Object.prototype.hasOwnProperty.call(obj, prop);
        }

        // parse output valuse
        function parse(lines) {
            lines = lines.filter(
                (line) => !line.match(/^\[.*Warning: not compiled with thread support/)
            );
            // This should now contain only common FFmpeg logging.
            const out = lines.join("\n");

            const dur = out.match(/^\s+Duration:\s+([^,]+)/m);
            assert(dur, "Failed to parse duration");
            const duration = parseTime(dur[1]);
            assert(duration, "Zero duration");

            let video = [];
            let audio = [];
            let subs = [];
            let tracks = {Video: video, Audio: audio, Subtitle: subs};
            let sre = /^\s+Stream\s+#0:(\d+)(?:\((\w+)\))?:\s+(\w+):\s+(\w+)(.*)/gm;
            let smatch, lastStream, lastIndex;
            let si = 0;

            function scanMetadata(index) {
                if (lastStream) {
                    const meta = out.slice(lastIndex, index);
                    const title = meta.match(/^\s+title\s*:\s*(.+)$/m);
                    if (title) lastStream.title = title[1];
                }
            }

            while ((smatch = sre.exec(out)) !== null) {
                const [id, lang, type, codec, rest] = smatch.slice(1);
                if (!has(tracks, type)) continue;
                let stream = {id, lang, codec};
                if (type === "Video") {
                    const resm = rest.match(/,\s+(\d+)x(\d+)[,\s]/);
                    assert(resm, "Failed to parse resolution");
                    stream.width = Number(resm[1]);
                    stream.height = Number(resm[2]);
                    const fpsm = rest.match(/\b(\d+(\.\d+)?)\s+fps\b/);
                    // assert(fpsm, "Failed to parse fps");
                    if (fpsm)
                        stream.fps = Number(fpsm[1]);
                    // assert(
                    //     stream.width && stream.height && stream.fps,
                    //     "Bad video params"
                    // );
                }
                if (type === "Subtitle") stream.si = si++;
                if (rest.match(/\(default\)/)) stream.default = true;
                if (rest.match(/\(forced\)/)) stream.forced = true;
                tracks[type].push(stream);
                scanMetadata(smatch.index);
                lastStream = stream;
                lastIndex = smatch.index;
            }
            scanMetadata();

            // assert(video.length, "No video tracks");
            assert(audio.length, "No Audio tracks");
            return {duration, video, audio, subs};
        }
    };
    init();


}
// const fds="../wp-content/plugins/sadaf-io/v.mp4";
// let file = new  FileReader(fds);
// console.log('gfd',file);
// download blob to user's browser
	