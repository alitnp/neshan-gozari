<?php
/*
Plugin Name: sadaf io
Plugin URI: http://idehweb.com/sadaf-io
Description: upload file using sadaf
Version: 1.0.0
Author: Hamid Alinia - idehweb
Author URI: http://idehweb.com
Text Domain: sadaf-io
Domain Path: /languages
*/
//require 'library/vendor/autoload.php';
//use FFMpeg\FFMpeg;

class idehwebSadafIo
{
    public $textdomain = 'sadaf-io';

    function __construct()
    {
        add_action('init', array(&$this, 'idehweb_sadafio_textdomain'));
        add_action('admin_init', array(&$this, 'admin_init'));
        add_action('admin_menu', array(&$this, 'admin_menu'));
        add_action('wp_enqueue_scripts', array(&$this, 'enqueue_scripts'));
        add_action('activated_plugin', array(&$this, 'sadafio_activation_redirect'));
        add_shortcode('idehweb_sadafio', array(&$this, 'shortcode'));
        add_action('add_meta_boxes', array($this, 'add_meta_box'));
        add_action('save_post', array($this, 'save'));

    }


    function sadafio_activation_redirect($plugin)
    {
        if ($plugin == plugin_basename(__FILE__)) {
            exit(wp_redirect(admin_url('admin.php?page=idehweb-sadafio')));
        }
    }

    function idehweb_sadafio_textdomain()
    {
        $idehweb_sadafio_lang_dir = dirname(plugin_basename(__FILE__)) . '/languages/';
        $idehweb_sadafio_lang_dir = apply_filters('idehweb_sadafio_languages_directory', $idehweb_sadafio_lang_dir);

        load_plugin_textdomain($this->textdomain, false, $idehweb_sadafio_lang_dir);


    }

    function admin_init()
    {
        $options = get_option('idehweb_sadafio_settings');


        register_setting('idehweb-sadafio', 'idehweb_sadafio_settings', array(&$this, 'settings_validate'));


        add_settings_section('idehweb-sadafio', '', array(&$this, 'section_intro'), 'idehweb-sadafio');

//        add_settings_field('idehweb_sadafio_file', __('Upload your file', $this->textdomain), array(&$this, 'setting_idehweb_sadafio_uploadfile'), 'idehweb-sadafio', 'idehweb-sadafio', ['class' => 'idehweb_sadafio']);
        // add_settings_field('idehweb_sadafio_count_of_slices', __('Count of slices', $this->textdomain), array(&$this, 'setting_idehweb_sadafio_count_of_slices'), 'idehweb-sadafio', 'idehweb-sadafio', ['class' => 'idehweb_sadafio']);
        // add_settings_field('idehweb_sadafio_count_of_slices_fau', __('Count of slices for audio file', $this->textdomain), array(&$this, 'setting_idehweb_sadafio_count_of_slices_fau'), 'idehweb-sadafio', 'idehweb-sadafio', ['class' => 'idehweb_sadafio']);
        // add_settings_field('idehweb_sadafio_duration_of_every_slice', __('Duration of each slices', $this->textdomain), array(&$this, 'setting_idehweb_sadafio_duration_of_every_slice'), 'idehweb-sadafio', 'idehweb-sadafio', ['class' => 'idehweb_sadafio']);
        // add_settings_field('idehweb_sadafio_duration_of_every_slice_fau', __('Duration of each slices for audio file', $this->textdomain), array(&$this, 'setting_idehweb_sadafio_duration_of_every_slice_fau'), 'idehweb-sadafio', 'idehweb-sadafio', ['class' => 'idehweb_sadafio']);
        // add_settings_field('idehweb_sadafio_phonenumber', __('PhoneNumber', $this->textdomain), array(&$this, 'setting_idehweb_sadafio_phonenumber'), 'idehweb-sadafio', 'idehweb-sadafio', ['class' => 'idehweb_sadafio']);
        // add_settings_field('idehweb_sadafio_melicode', __('MeliCode', $this->textdomain), array(&$this, 'setting_idehweb_sadafio_melicode'), 'idehweb-sadafio', 'idehweb-sadafio', ['class' => 'idehweb_sadafio']);
        // add_settings_field('idehweb_sadafio_company_melicode', __('Company MeliCode', $this->textdomain), array(&$this, 'setting_idehweb_sadafio_company_melicode'), 'idehweb-sadafio', 'idehweb-sadafio', ['class' => 'idehweb_sadafio']);
        add_settings_field('idehweb_sadafio_header_api', __('Header Api', $this->textdomain), array(&$this, 'setting_idehweb_sadafio_header_api'), 'idehweb-sadafio', 'idehweb-sadafio', ['class' => 'idehweb_sadafio']);

    }

    function admin_menu()
    {

        $icon_url = 'dashicons-smartphone';
        $page_hook = add_menu_page(
            __('Sadaf Io', $this->textdomain),
            __('Sadaf Io', $this->textdomain),
            'manage_options',
            'idehweb-sadafio',
            array(&$this, 'settings_page'),
            $icon_url
        );
        $options = get_option('idehweb_sadafio_settings');
        // if (!isset($options['idehweb_sadafio_count_of_slices'])) $options['idehweb_sadafio_count_of_slices'] = '5';
        // if (!isset($options['idehweb_sadafio_count_of_slices_fau'])) $options['idehweb_sadafio_count_of_slices_fau'] = '5';
        // if (!isset($options['idehweb_sadafio_duration_of_every_slice'])) $options['idehweb_sadafio_duration_of_every_slice'] = '10';
        // if (!isset($options['idehweb_sadafio_duration_of_every_slice_fau'])) $options['idehweb_sadafio_duration_of_every_slice_fau'] = '10';
        // if (!isset($options['idehweb_sadafio_phonenumber'])) $options['idehweb_sadafio_phonenumber'] = '';
        // if (!isset($options['idehweb_sadafio_melicode'])) $options['idehweb_sadafio_melicode'] = '';
        // if (!isset($options['idehweb_sadafio_company_melicode'])) $options['idehweb_sadafio_company_melicode'] = '';
        if (!isset($options['idehweb_sadafio_header_api'])) $options['idehweb_sadafio_header_api'] = '';


//        add_action('admin_print_styles-' . $page_hook, array(&$this, 'admin_custom_css'));
         wp_enqueue_style('idehweb-sadafio-admin', plugins_url('/styles/sadaf-io-admin.css', __FILE__));

        // wp_enqueue_script('idehweb-sadafio-external-admin', "https://api-maps.yandex.ru/2.1/?apikey=$api&lang=$lang", array('jquery'));
        wp_enqueue_script('idehweb-sadafio-ffmpegadmin-js', plugins_url('/scripts/ffmpeg-worker.js', __FILE__), array('jquery'), true, true);
        wp_enqueue_script('idehweb-sadafio-admin-js', plugins_url('/scripts/sadaf-io-admin.js', __FILE__), array('jquery'), true, true);

        $localize = array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            // 'count_of_slices' => $options['idehweb_sadafio_count_of_slices'],
            // 'count_of_slices_fau' => $options['idehweb_sadafio_count_of_slices_fau'],
            // 'duration_of_every_slice' => $options['idehweb_sadafio_duration_of_every_slice'],
            // 'duration_of_every_slice_fau' => $options['idehweb_sadafio_duration_of_every_slice_fau'],
            // 'phonenumber' => $options['idehweb_sadafio_phonenumber'],
            // 'melicode' => $options['idehweb_sadafio_melicode'],
            // 'companymelicode' => $options['idehweb_sadafio_company_melicode'],
            'header_api' => $options['idehweb_sadafio_header_api']
        );

        wp_localize_script('idehweb-sadafio-admin-js', 'idehweb_sadafio', $localize);
    }

//    function admin_custom_css()
//    {
//        wp_enqueue_style('idehweb-sadafio-admin', plugins_url('/styles/sadafio-admin.css', __FILE__));
//
//
//    }

    function settings_page()
    {
        $options = get_option('idehweb_sadafio_settings');
        if (!isset($options['idehweb_phone_number'])) $options['idehweb_phone_number'] = '';

        ?>
        <div class="wrap">
            <div id="icon-themes" class="icon32"></div>
            <h2><?php _e('Sadaf Io Settings', $this->textdomain); ?></h2>
            <?php

            //             $ffmpeg = FFMpeg\FFMpeg::create(array(
            //                 'ffmpeg.binaries'  => '/usr/local/bin/ffmpeg',
            //                 'ffprobe.binaries' => '/usr/local/bin/ffprobe',
            //                 'timeout'          => 3600, // The timeout for the underlying process
            //                 'ffmpeg.threads'   => 12,   // The number of threads that FFMpeg should use
            //             ));
            //            $videoPath=plugins_url('/v.mp4', __FILE__);
            //            $video = $ffmpeg->open($videoPath);
            //            $video
            //                ->filters()
            //                ->resize(new FFMpeg\Coordinate\Dimension(320, 240))
            //                ->synchronize();
            //            $video
            //                ->frame(FFMpeg\Coordinate\TimeCode::fromSeconds(10))
            //                ->save('frame.jpg');
            if (isset($_GET['settings-updated']) && $_GET['settings-updated']) {

                ?>
                <div id="setting-error-settings_updated" class="updated settings-error">
                    <p><strong><?php _e('Settings saved.', $this->textdomain); ?></strong></p>
                </div>
            <?php } ?>
            <form action="options.php" method="post" id="iuytfrdghj">
                <?php settings_fields('idehweb-sadafio'); ?>
                <?php do_settings_sections('idehweb-sadafio'); ?>

                <p class="submit">
                    <span id="wkdugchgwfchevg3r4r"></span>
                </p>
                <p class="submit">
                    <span id="oihdfvygehv"></span>
                </p>
                <p class="submit">
                    <input type="submit" class="button-primary"
                           value="<?php _e('Save Changes', $this->textdomain); ?>"/></p>

            </form>


            <script>
                <?php

                ?>
                jQuery(function ($) {
                });
            </script>
        </div>
        <?php
    }


    function section_intro()
    {
        ?>

        <?php

    }

    function section_title()
    {
        ?>
        <!--        jhgjk-->

        <?php

    }

    function settings_validate($input)
    {

        return $input;
    }

    function enqueue_scripts()
    {
        $options = get_option('idehweb_sadafio_settings');
//        if (!isset($options['idehweb_sadafio_api'])) $options['idehweb_sadafio_api'] = '';
//        if (!isset($options['idehweb_sadafio_count_of_slices'])) $options['idehweb_sadafio_count_of_slices'] = '5';
//        if (!isset($options['idehweb_sadafio_duration_of_every_slice'])) $options['idehweb_sadafio_duration_of_every_slice'] = '10';
////        if (!isset($options['idehweb_sadafio_city_id_field'])) $options['idehweb_sadafio_city_id_field'] = 'billing_city';
////        $lang = $options['idehweb_sadafio_language'];
//        $localize = array(
//            'ajaxurl' => admin_url('admin-ajax.php'),
//            'count_of_slices' => $options['idehweb_sadafio_count_of_slices'],
//            'duration_of_every_slice' => $options['idehweb_sadafio_duration_of_every_slice'],
////            'UserId' => 0,
////            'IamHere' => __('I am here', $thi/s->textdomain),
////            'yandexidfiled' => $options['idehweb_sadafio_id_field'],
////            'yandex_billing_city' => $options['idehweb_sadafio_city_id_field'],
//        );
//
////        $api = $options['idehweb_sadafio_api'];
//        // if ($api) {
//        //     wp_enqueue_style('idehweb-sadafio-css', plugins_url('/styles/sadaf-io.css', __FILE__));
//
//        //     wp_enqueue_script('idehweb-sadafio-external', "https://api-maps.yandex.ru/2.1/?apikey=$api&lang=$lang", array('jquery'));
//            // wp_enqueue_script('idehweb-sadafio-js', plugins_url('/scripts/sadaf-io.js', __FILE__), array('jquery'));
//        // }
//         wp_localize_script('idehweb-sadafio-js', 'idehweb_sadafio', $localize);
//        if ($options['idehweb_use_custom_gateway'] == '1' && $options['idehweb_default_gateways'] === 'firebase') {
//
//            wp_add_inline_script('idehweb-sadafio', '' . htmlspecialchars_decode($options['idehweb_firebase_config']));
//        }

    }


    function shortcode($atts)
    {

        extract(shortcode_atts(array(
            'redirect_url' => ''
        ), $atts));
        ob_start();
        $options = get_option('idehweb_sadafio_settings');

        ?>
        <!--        <div id="map" style="width: 600px; height: 400px"></div-->
        <?php
        return ob_get_clean();
    }

//
//    function setting_idehweb_sadafio_uploadfile()
//    {
//        $options = get_option('idehweb_sadafio_settings');
//        if (!isset($options['idehweb_sadafio_api'])) $options['idehweb_sadafio_api'] = '';
//
//        echo '<input id="sadafio_token" type="file" onchange="openFile(event)"  class="regular-text" />
//		<p class="description">' . __('upload your file', $this->textdomain) . '</p><div class="sdfghghfdercfr"></div> ';
//
//    }
    function setting_idehweb_sadafio_count_of_slices()
    {
        $options = get_option('idehweb_sadafio_settings');
        if (!isset($options['idehweb_sadafio_count_of_slices'])) $options['idehweb_sadafio_count_of_slices'] = '5';

        echo '<input id="sadafio_count_of_slices" type="text" name="idehweb_sadafio_settings[idehweb_sadafio_count_of_slices]" class="regular-text" value="' . esc_attr($options['idehweb_sadafio_count_of_slices']) . '" />
		<p class="description">' . __('count of slices', $this->textdomain) . '</p>';

    }
    function setting_idehweb_sadafio_count_of_slices_fau()
    {
        $options = get_option('idehweb_sadafio_settings');
        if (!isset($options['idehweb_sadafio_count_of_slices_fau'])) $options['idehweb_sadafio_count_of_slices_fau'] = '5';

        echo '<input id="sadafio_count_of_slices_fau" type="text" name="idehweb_sadafio_settings[idehweb_sadafio_count_of_slices_fau]" class="regular-text" value="' . esc_attr($options['idehweb_sadafio_count_of_slices_fau']) . '" />
		<p class="description">' . __('count of slices for audio file', $this->textdomain) . '</p>';

    }

    function setting_idehweb_sadafio_duration_of_every_slice()
    {
        $options = get_option('idehweb_sadafio_settings');
        if (!isset($options['idehweb_sadafio_duration_of_every_slice'])) $options['idehweb_sadafio_duration_of_every_slice'] = '10';

        echo '<input id="sadafio_duration_of_every_slice" type="text" name="idehweb_sadafio_settings[idehweb_sadafio_duration_of_every_slice]" class="regular-text" value="' . esc_attr($options['idehweb_sadafio_duration_of_every_slice']) . '" />
		<p class="description">' . __('duration of each slice', $this->textdomain) . '</p>';

    }
    function setting_idehweb_sadafio_duration_of_every_slice_fau()
    {
        $options = get_option('idehweb_sadafio_settings');
        if (!isset($options['idehweb_sadafio_duration_of_every_slice_fau'])) $options['idehweb_sadafio_duration_of_every_slice_fau'] = '10';

        echo '<input id="sadafio_duration_of_every_slice_fau" type="text" name="idehweb_sadafio_settings[idehweb_sadafio_duration_of_every_slice_fau]" class="regular-text" value="' . esc_attr($options['idehweb_sadafio_duration_of_every_slice_fau']) . '" />
		<p class="description">' . __('duration of each slice for audio file', $this->textdomain) . '</p>';

    }

    function setting_idehweb_sadafio_phonenumber()
    {
        $options = get_option('idehweb_sadafio_settings');
        if (!isset($options['idehweb_sadafio_phonenumber'])) $options['idehweb_sadafio_phonenumber'] = '';

        echo '<input id="sadafio_phonenumber" type="text" name="idehweb_sadafio_settings[idehweb_sadafio_phonenumber]" class="regular-text" value="' . esc_attr($options['idehweb_sadafio_phonenumber']) . '" />
		<p class="description">' . __('phone number', $this->textdomain) . '</p>';

    }

    function setting_idehweb_sadafio_melicode()
    {
        $options = get_option('idehweb_sadafio_settings');
        if (!isset($options['idehweb_sadafio_melicode'])) $options['idehweb_sadafio_melicode'] = '';

        echo '<input id="sadafio_melicode" type="text" name="idehweb_sadafio_settings[idehweb_sadafio_melicode]" class="regular-text" value="' . esc_attr($options['idehweb_sadafio_melicode']) . '" />
		<p class="description">' . __('melli code', $this->textdomain) . '</p>';

    }

    function setting_idehweb_sadafio_company_melicode()
    {
        $options = get_option('idehweb_sadafio_settings');
        if (!isset($options['idehweb_sadafio_company_melicode'])) $options['idehweb_sadafio_company_melicode'] = '';

        echo '<input id="sadafio_company_melicode" type="text" name="idehweb_sadafio_settings[idehweb_sadafio_company_melicode]" class="regular-text" value="' . esc_attr($options['idehweb_sadafio_company_melicode']) . '" />
		<p class="description">' . __('company melli code', $this->textdomain) . '</p>';

    }

    function setting_idehweb_sadafio_header_api()
    {
        $options = get_option('idehweb_sadafio_settings');
        if (!isset($options['idehweb_sadafio_header_api'])) $options['idehweb_sadafio_header_api'] = '';

        echo '<input id="sadafio_header_api" type="text" name="idehweb_sadafio_settings[idehweb_sadafio_header_api]" class="regular-text" value="' . esc_attr($options['idehweb_sadafio_header_api']) . '" />
		<p class="description">' . __('header api', $this->textdomain) . '</p>';

    }

    public function add_meta_box($post_type)
    {
        // Limit meta box to certain post types.
        $post_types = array('post', 'page');

        if (in_array($post_type, $post_types)) {
            add_meta_box(
                'some_meta_box_name',
                __('Upload to Sadaf io', 'textdomain'),
                array($this, 'render_meta_box_content'),
                $post_type,
                'advanced',
                'high'
            );
        }
    }

    public function save($post_id)
    {

        /*
         * We need to verify this came from the our screen and with proper authorization,
         * because save_post can be triggered at other times.
         */

//        // Check if our nonce is set.
//        if (!isset($_POST['myplugin_inner_custom_box_nonce'])) {
//            return $post_id;
//        }
//
//        $nonce = $_POST['myplugin_inner_custom_box_nonce'];
//
//        // Verify that the nonce is valid.
//        if (!wp_verify_nonce($nonce, 'myplugin_inner_custom_box')) {
//            return $post_id;
//        }
//
//        /*
//         * If this is an autosave, our form has not been submitted,
//         * so we don't want to do anything.
//         */
//        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
//            return $post_id;
//        }
//
//        // Check the user's permissions.
//        if ('page' == $_POST['post_type']) {
//            if (!current_user_can('edit_page', $post_id)) {
//                return $post_id;
//            }
//        } else {
//            if (!current_user_can('edit_post', $post_id)) {
//                return $post_id;
//            }
//        }
//
//        /* OK, it's safe for us to save the data now. */
//
//        // Sanitize the user input.
//        $mydata = sanitize_text_field($_POST['myplugin_new_field']);
//
//        // Update the meta field.
//        update_post_meta($post_id, '_my_meta_value_key', $mydata);
    }


    /**
     * Render Meta Box content.
     *
     * @param WP_Post $post The post object.
     */
    public function render_meta_box_content($post)
    {
        $options = get_option('idehweb_sadafio_settings');
        // if (!isset($options['idehweb_sadafio_melicode'])) $options['idehweb_sadafio_melicode'] = '';
        // if (!isset($options['idehweb_sadafio_phonenumber'])) $options['idehweb_sadafio_phonenumber'] = '';
        // if (!isset($options['idehweb_sadafio_company_melicode'])) $options['idehweb_sadafio_company_melicode'] = '';

        // Add an nonce field so we can check for it later.
        wp_nonce_field('myplugin_inner_custom_box', 'myplugin_inner_custom_box_nonce');

        // Use get_post_meta to retrieve an existing value from the database.
//        $value = get_post_meta( $post->ID, '_my_meta_value_key', true );

        // Display the form, using the current value.
        ?>
        <!--        <label for="myplugin_new_field">-->
        <!--            --><?php //_e( 'Description for this field', 'textdomain' );
        ?>
        <!--        </label>-->
        <!--        <input type="text" id="myplugin_new_field" name="myplugin_new_field" value="--><?php //echo esc_attr( $value );
        ?><!--" size="25" />-->
        <!--        --><?php ?>
        <div class="hgfdsadfgf">
            <div class="top-jhgfghj">
                <a href="#" class="kjhg v1">upload via file</a>
                <a href="#" class="kjhg v2">upload via url</a>
            </div>
            <div class="gfdewedrf kjhgfrdfghuj1  ">
                <form enctype="multipart/form-data" method="post" id="fileinfo" name="fileinfo">
                    <div class="kjhgfghu">
                        <div class="components-panel__row"><span>File</span>
                            <div class="components-dropdown">
                                <input id="sadafio_token" type="file" name="filex1" class="regular-text"/>

                            </div>
                        </div>
                        <div class="components-panel__row">

                        </div>

                        <!-- <div class="components-panel__row"><span>Phone number</span>
                            <div class="components-dropdown">
                                <input id="sadafio_phonenumber" type="text"
                                       placeholder="<?php echo $options['idehweb_sadafio_phonenumber']; ?>"
                                       value="<?php echo $options['idehweb_sadafio_phonenumber']; ?>"
                                       name="sadafio_phonenumber"
                                       class="regular-text"/>
                            </div>
                        </div>
                        <div class="components-panel__row"><span>Melli code</span>
                            <div class="components-dropdown">
                                <input id="sadafio_melicode" type="text"
                                       placeholder="<?php echo $options['idehweb_sadafio_melicode']; ?>"
                                       value="<?php echo $options['idehweb_sadafio_melicode']; ?>"
                                       name="sadafio_melicode" class="regular-text"/>
                            </div>
                        </div>
                        <div class="components-panel__row"><span>Company melli code</span>
                            <div class="components-dropdown">
                                <input id="sadafio_company_melicode" type="text"
                                       placeholder="<?php echo $options['idehweb_sadafio_company_melicode']; ?>"
                                       value="<?php echo $options['idehweb_sadafio_company_melicode']; ?>"
                                       name="sadafio_melicode" class="regular-text"/>
                            </div>
                        </div> -->


                    </div>
                    <div class="kiuygfdgh">
                        <button class="components-button is-primary" type="submit" onclick="openFile(event)">submit file
                        </button>
                    </div>
                    <p class="description">upload your file</p>
                    <div class="sdfghghfdercfr"></div>
                </form>
            </div>
            <div class="gfdewedrf kjhgfrdfghuj2 none">
                <form enctype="multipart/form-data" method="post" id="fileinfo" name="fileinfo">
                    <div class="kjhgfghu">
                        <div class="components-panel__row"><span>File url</span>
                            <div class="components-dropdown">
                                <input id="sadafio_token_url" type="text" name="filex1" class="regular-text"/>

                            </div>
                        </div>
                        <!-- <div class="components-panel__row"><span>What is this link?</span>
                            <div class="components-dropdown">
                                <label>128</label>
                                <input id="sadafio_url_choose_type1" checked type="radio" name="choose_type_url" value="128" class="regular-text"/>

                            </div>
                            <div class="components-dropdown">
                                <label>320</label>
                                <input id="sadafio_url_choose_type2" type="radio" name="choose_type_url" value="320" class="regular-text"/>

                            </div>
                            <div class="components-dropdown">
                                <label>1080 video</label>
                                <input id="sadafio_url_choose_type3" type="radio" name="choose_type_url" value="1080" class="regular-text"/>

                            </div>
                            <div class="components-dropdown">
                                <label>720 video</label>
                                <input id="sadafio_url_choose_type4" type="radio" name="choose_type_url" value="720" class="regular-text"/>

                            </div>
                            <div class="components-dropdown">
                                <label>480 video</label>
                                <input id="sadafio_url_choose_type5" type="radio" name="choose_type_url" value="480" class="regular-text"/>

                            </div>
                        </div> -->
                        <!-- <div class="components-panel__row"><span>Phone number</span>
                            <div class="components-dropdown">
                                <input id="sadafio_phonenumber_url" type="text"
                                       placeholder="<?php echo $options['idehweb_sadafio_phonenumber']; ?>"
                                       value="<?php echo $options['idehweb_sadafio_phonenumber']; ?>"
                                       name="sadafio_phonenumber"
                                       class="regular-text"/>
                            </div>
                        </div>
                        <div class="components-panel__row"><span>Melli code</span>
                            <div class="components-dropdown">
                                <input id="sadafio_melicode_url" type="text"
                                       placeholder="<?php echo $options['idehweb_sadafio_melicode']; ?>"
                                       value="<?php echo $options['idehweb_sadafio_melicode']; ?>"
                                       name="sadafio_melicode" class="regular-text"/>
                            </div>
                        </div>
                        <div class="components-panel__row"><span>Company melli code</span>
                            <div class="components-dropdown">
                                <input id="sadafio_company_melicode_url" type="text"
                                       placeholder="<?php echo $options['idehweb_sadafio_company_melicode']; ?>"
                                       value="<?php echo $options['idehweb_sadafio_company_melicode']; ?>"
                                       name="sadafio_melicode" class="regular-text"/>
                            </div>
                        </div> -->


                    </div>
                    <div class="kiuygfdgh">
                        <button class="components-button is-primary jkhgfdfgh" type="submit">submit url
                        </button>
                    </div>
                    <p class="description">upload your file</p>
                    <div class="sdfghghfdercfr"></div>
                </form>
            </div>
        </div>

        <?php
    }
}

global $idehwebSadafIo;
$idehwebSadafIo = new idehwebSadafIo();

/**
 * Template Tag
 */
function idehweb_sadafio()
{

}



