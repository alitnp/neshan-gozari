=== Sadaf Uploader IO ===
Contributors: idehweb, hamid alinia
Requires at least: 3.4
Tested up to: 5.8
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==
sadaf io upload file


== Installation ==

1. download plugin and install
1. use page to upload file


== Changelog ==

= 1.0.0 =
Initial release

